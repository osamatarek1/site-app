import 'package:flutter/material.dart';
import 'package:whatsappsender/utill/colors.dart';
import 'package:whatsappsender/view_models/auth_provider.dart';
import 'package:whatsappsender/view_models/report_provider.dart';
import 'package:whatsappsender/view_models/send_provider.dart';
import 'package:whatsappsender/views/splash/splash_screen.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';

void main()async {
  // WidgetsFlutterBinding.ensureInitialized();
  // await Firebase.initializeApp();
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(
        create: (_) => AuthProvider(),
      ),
      ChangeNotifierProvider(
        create: (_) => SendProvider(),
      ),
      ChangeNotifierProvider(
        create: (_) => ReportProvider(),
      )
    ],
    child: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Whatsapp Sender',
      theme: ThemeData(
        primaryColor: AppColors.appColor,
        textTheme: GoogleFonts.aleoTextTheme(
          Theme.of(context).textTheme,
        ),
      ),
      home: SplashScreen(),
    );
  }
}
