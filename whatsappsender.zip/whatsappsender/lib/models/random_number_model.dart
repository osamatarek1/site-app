// To parse this JSON data, do
//
//     final randomNumberModel = randomNumberModelFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

RandomNumberModel randomNumberModelFromJson(String str) => RandomNumberModel.fromJson(json.decode(str));

String randomNumberModelToJson(RandomNumberModel data) => json.encode(data.toJson());

class RandomNumberModel {
  RandomNumberModel({
    required this.randomNumberModelInt,
    required this.phones,
    required this.name,
    required this.clientId,
    required this.userId,
    required this.userUnderId,
    required this.sentTime,
    required this.sent,
    required this.message,
    required this.campaignId,
    required this.bind,
    required this.exist,
    required this.picture,
    required this.file,
    required this.video,
  });

  int randomNumberModelInt;
  String phones;
  String name;
  int clientId;
  int userId;
  int userUnderId;
  DateTime sentTime;
  bool sent;
  String message;
  int campaignId;
  bool bind;
  bool exist;
  String picture;
  String file;
  String video;

  factory RandomNumberModel.fromJson(Map<String, dynamic> json) => RandomNumberModel(
    randomNumberModelInt: json["int"],
    phones: json["phones"],
    name: json["name"],
    clientId: json["clientId"],
    userId: json["userId"],
    userUnderId: json["userUnderId"],
    sentTime: DateTime.parse(json["sentTime"]),
    sent: json["sent"],
    message: json["message"],
    campaignId: json["campaignId"],
    bind: json["bind"],
    exist: json["exist"],
    file: json["file"]??"",
    video: json["video"]??"",
    picture: json["picture"] == null?'':json["picture"],
  );

  Map<String, dynamic> toJson() => {
    "int": randomNumberModelInt,
    "phones": phones,
    "name": name,
    "clientId": clientId,
    "userId": userId,
    "userUnderId": userUnderId,
    "sentTime": sentTime.toIso8601String(),
    "sent": sent,
    "message": message,
    "campaignId": campaignId,
    "bind": bind,
    "exist": exist,
    "picture": picture,
  };
}
