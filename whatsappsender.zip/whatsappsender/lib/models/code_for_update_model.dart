// To parse this JSON data, do
//
//     final codeForUpdateModel = codeForUpdateModelFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

List<CodeForUpdateModel> codeForUpdateModelFromJson(String str) => List<CodeForUpdateModel>.from(json.decode(str).map((x) => CodeForUpdateModel.fromJson(x)));

String codeForUpdateModelToJson(List<CodeForUpdateModel> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class CodeForUpdateModel {
  CodeForUpdateModel({
    required this.id,
    required this.appNumber1,
  });

  int id;
  int appNumber1;

  factory CodeForUpdateModel.fromJson(Map<String, dynamic> json) => CodeForUpdateModel(
    id: json["id"],
    appNumber1: json["appNumber1"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "appNumber1": appNumber1,
  };
}
