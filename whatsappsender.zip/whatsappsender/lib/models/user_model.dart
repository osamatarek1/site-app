// To parse this JSON data, do
//
//     final userModel = userModelFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

UserModel userModelFromJson(String str) => UserModel.fromJson(json.decode(str));

String userModelToJson(UserModel data) => json.encode(data.toJson());

class UserModel {
  UserModel({
    required this.id,
    required this.userName,
    required this.passWord,
    required this.loginDate,
    required this.permissions,
    required this.messagesSent,
    required this.fullName,
    required this.mobile,
  });

  int id;
  String userName;
  String passWord;
  String loginDate;
  int permissions;
  int messagesSent;
  String fullName;
  String mobile;

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    id: json["id"],
    userName: json["userName"],
    passWord: json["passWord"],
    loginDate: json["loginDate"],
    permissions: json["permissions"],
    messagesSent: json["messagesSent"],
    fullName: json["fullName"],
    mobile: json["mobile"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userName": userName,
    "passWord": passWord,
    "loginDate": loginDate,
    "permissions": permissions,
    "messagesSent": messagesSent,
    "fullName": fullName,
    "mobile": mobile,
  };
}
