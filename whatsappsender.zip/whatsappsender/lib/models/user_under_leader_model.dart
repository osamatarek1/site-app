// To parse this JSON data, do
//
//     final userUnderLeaderModel = userUnderLeaderModelFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

UserUnderLeaderModel userUnderLeaderModelFromJson(String str) => UserUnderLeaderModel.fromJson(json.decode(str));

String userUnderLeaderModelToJson(UserUnderLeaderModel data) => json.encode(data.toJson());

class UserUnderLeaderModel {
  UserUnderLeaderModel({
    required this.id,
    required this.userName,
    required this.passWord,
    required this.loginDate,
    required this.messagesSent,
    required this.pid,
    required this.userParent,
    required this.fullName,
    required this.mobile,
  });

  int id;
  String userName;
  String passWord;
  String loginDate;
  int messagesSent;
  int pid;
  String userParent;
  String fullName;
  String mobile;

  factory UserUnderLeaderModel.fromJson(Map<String, dynamic> json) => UserUnderLeaderModel(
    id: json["id"],
    userName: json["userName"],
    passWord: json["passWord"],
    loginDate: json["loginDate"],
    messagesSent: json["messagesSent"],
    pid: json["pid"],
    userParent: json["userParent"],
    fullName: json["fullName"],
    mobile: json["mobile"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userName": userName,
    "passWord": passWord,
    "loginDate": loginDate,
    "messagesSent": messagesSent,
    "pid": pid,
    "userParent": userParent,
    "fullName": fullName,
    "mobile": mobile,
  };
}
