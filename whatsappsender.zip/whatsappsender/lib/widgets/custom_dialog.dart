import 'package:flutter/material.dart';
import 'package:whatsappsender/utill/colors.dart';
import 'package:provider/provider.dart';
import 'package:whatsappsender/view_models/auth_provider.dart';
import 'package:whatsappsender/views/login/login_screen.dart';


class CustomAlertDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Dialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0)
        ),
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircleAvatar(
                    backgroundColor: AppColors.appColor,
                    radius: 35,
                    child: Icon(Icons.logout, color: Colors.white, size: 30,),
                  ),
                  SizedBox(height: 20,),
                  Text('LogOut', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),),
                  SizedBox(height: 5,),
                  Text('Do you want to exit from Whatsapp sender?',textAlign: TextAlign.center, style: TextStyle(fontSize:15),),
                  SizedBox(height: 20,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      ElevatedButton(
                        child: Padding(
                          padding: const EdgeInsets.all(14.0),
                          child: Text(
                            'Yes',
                            style: TextStyle(fontSize: 15),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        style: ButtonStyle(
                          backgroundColor:
                          MaterialStateProperty.all<Color>(
                              AppColors.appColor),
                          shape: MaterialStateProperty.all<
                              RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(50.0),
                            ),
                          ),
                        ),
                        onPressed: () async {
                          Provider.of<AuthProvider>(context,listen: false).logOut();
                          Navigator.of(context).pop();
                          Navigator.of(context).pushReplacement(
                            MaterialPageRoute(
                              builder: (context) => LoginScreen(),
                            ),
                          );
                        },
                      ),
                      ElevatedButton(
                        child: Padding(
                          padding: const EdgeInsets.all(14.0),
                          child: Text(
                            'No',
                            style: TextStyle(fontSize: 15),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        style: ButtonStyle(
                          backgroundColor:
                          MaterialStateProperty.all<Color>(
                              AppColors.appColor),
                          shape: MaterialStateProperty.all<
                              RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(50.0),
                            ),
                          ),
                        ),
                        onPressed: () async {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Positioned(
            //     top: 0,
            //     child: CircleAvatar(
            //       backgroundColor: AppColors.appColor,
            //       radius: 35,
            //       child: Icon(Icons.logout, color: Colors.white, size: 30,),
            //     )
            // ),
          ],
        )
    );
  }
}