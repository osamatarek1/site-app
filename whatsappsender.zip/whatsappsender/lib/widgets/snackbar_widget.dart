import 'package:flutter/material.dart';
import 'package:whatsappsender/utill/colors.dart';

SnackBar displaySnackBar(String msg) {
  return SnackBar(
    backgroundColor: AppColors.appColor,
    content: Text(
      msg,
      textAlign: TextAlign.center,
      style: TextStyle(
        color: Colors.white,
        fontStyle: FontStyle.italic,
      ),
    ),
  );
}
