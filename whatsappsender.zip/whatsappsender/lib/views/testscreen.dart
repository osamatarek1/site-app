import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TestScreen extends StatefulWidget {
  const TestScreen({Key? key}) : super(key: key);

  @override
  _TestScreenState createState() => _TestScreenState();
}

class _TestScreenState extends State<TestScreen> {
  static const platform = MethodChannel('samples.flutter.dev/battery');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: TextButton(
          child: Text('send'),
          onPressed: () async {
            String batteryLevel;
            try {
              await platform.invokeMethod('sendMessage', {'msg': 'hello  bs:MESSAGE', 'phone': '+201006126863'});

            } on PlatformException catch (e) {
              batteryLevel = "Failed to get battery level: '${e.message}'.";
            }
          },
        ),
      ),
    );
  }
}
