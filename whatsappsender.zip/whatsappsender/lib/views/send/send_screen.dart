import 'dart:async';
import 'package:device_apps/device_apps.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:whatsappsender/utill/colors.dart';
import 'package:whatsappsender/utill/user_prefrences.dart';
import 'package:whatsappsender/view_models/auth_provider.dart';
import 'package:whatsappsender/view_models/send_provider.dart';
import 'package:whatsappsender/widgets/custom_dialog.dart';
import 'package:provider/provider.dart';
import 'package:permission_handler/permission_handler.dart';

class SendScreen extends StatefulWidget {
  const SendScreen({Key? key}) : super(key: key);

  @override
  _SendScreenState createState() => _SendScreenState();
}

enum sendType {
  TEXT,
  PHOTO,
  VIDEO,
  PDF,
}

class _SendScreenState extends State<SendScreen> {
  int selectedApp = -1;
  bool isFirst = true;
  sendType _sendType = sendType.TEXT;
  static const platform = MethodChannel('samples.flutter.dev/battery');
  TextEditingController _messageController = TextEditingController();
  String fileURL = '';
  String fileName = '';
  String mainMessage = '';
  String welcomeMessage = '';

  late Timer _timer;
  late Timer _timer2;
  late Timer _timer3;
  // int _start = 5;
  int _start2 = 10;
  int _start3 = 10;

  bool isDownloading = false;
  bool isWelcome = true;


  void resetData(){
    setState(() {
      selectedApp = -1;
      isFirst = true;
      _sendType = sendType.TEXT;
      fileURL='';
      fileName = '';
      mainMessage = '';
      welcomeMessage = '';
      // _start = 3;
      _start2 =10;
      isWelcome = true;
      isDownloading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    // startTimer();
    getNewNumberTimer();
    // waitingForSend();
    checkLoginDate();
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      loadData();
    });
  }

  Future loadData() async {
    final sendProvider = Provider.of<SendProvider>(context, listen: false);
    await sendProvider.getRandomNumber();
    _messageController.text = sendProvider.randomNumberData.message;
    getSendTypeAndData();
  }

  printData(){
    final sendProvider = Provider.of<SendProvider>(context, listen: false);
    // print('========>Photo: ${sendProvider.randomNumberData.picture}');
    // print('========>Video: ${sendProvider.randomNumberData.video}');
    // print('========>File: ${sendProvider.randomNumberData.file}');
    // print('========>IsWelcome: $isWelcome');
    // print('========>FileType: $_sendType');
    // print('========>Welcome Message: '+welcomeMessage);
    // print('========>Main Message: '+mainMessage);
  }

  Future<bool> getPermission()async{
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final sendProvider = Provider.of<SendProvider>(context);
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).primaryColor,
          title: Text("Send"),
          actions: [
            IconButton(
              icon: Icon(Icons.logout),
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (context) {
                      return CustomAlertDialog();
                    });
                // authProvider.logOut();
              },
            ),
          ],
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              children: [
                Container(
                  alignment: Alignment.center,
                  child: Image.asset(
                    'assets/images/loginlogo.png',
                    width: 150,
                  ),
                ),
                Row(
                  children: [
                    Container(
                        child: Text(
                      'Campaign ID:',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: AppColors.appColor,
                      ),
                    )),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      child: Container(
                        alignment: Alignment.center,
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Text(
                            sendProvider.isLoading
                                ? 'loading...'
                                : sendProvider.randomNumberData.campaignId
                                            .toString() ==
                                        "-1"
                                    ? "No Campaign Id"
                                    : sendProvider.randomNumberData.campaignId
                                        .toString(),
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: AppColors.appColor,
                            ),
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: Colors.grey.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  children: [
                    Container(
                        child: Text(
                      'Phone Number:',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: AppColors.appColor,
                      ),
                    )),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      child: Container(
                        alignment: Alignment.center,
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Text(
                            sendProvider.isLoading
                                ? 'loading...'
                                : sendProvider.randomNumberData.phones
                                            .toString() ==
                                        ""
                                    ? "No Phone number"
                                    : sendProvider.randomNumberData.phones
                                        .toString(),
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: AppColors.appColor,
                            ),
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: Colors.grey.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                TextField(
                  controller: _messageController,
                  keyboardType: TextInputType.multiline,
                  maxLines: 15,
                  enabled: false,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    // isDense: true,
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(20.0)),
                        borderSide: BorderSide(color: AppColors.appColor)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                      borderSide: BorderSide(
                        width: 0,
                        style: BorderStyle.none,
                      ),
                    ),
                    fillColor: Colors.grey.withOpacity(0.2),
                    filled: true,
                    contentPadding: EdgeInsets.all(20),
                    hintText: sendProvider.isLoading
                        ? 'loading...'
                        : 'Press new number button',
                    // labelStyle: ,
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  child: Text(
                      'if you want to send file, please send message first to the number then send the file.'),
                ),
                SizedBox(
                  height: 20,
                ),
                SizedBox(
                  height: 10,
                ),
                // _start != 0
                //     ? Container(
                //         alignment: Alignment.center,
                //         width: MediaQuery.of(context).size.width,
                //         decoration: BoxDecoration(
                //             color: AppColors.appColor,
                //             borderRadius: BorderRadius.circular(50.0)),
                //         child: Padding(
                //           padding: const EdgeInsets.all(15.0),
                //           child: Text('Waiting..$_start',
                //               style: TextStyle(color: Colors.white)),
                //         ))
                //     :
                Container(
                        width: MediaQuery.of(context).size.width,
                        child: ElevatedButton(
                          child: Padding(
                            padding: const EdgeInsets.all(14.0),
                            child: Text('Send',
                              style: TextStyle(fontSize: 15),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                AppColors.appColor),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(50.0),
                              ),
                            ),
                          ),
                          onPressed:() async {
                            setState(() {
                              _start2 = 10;
                            });
                            showModalBottomSheet<void>(
                              context: context,
                              builder: (BuildContext context) {
                                return Container(
                                  color: AppColors.appColor,
                                  height:
                                      MediaQuery.of(context).size.height / 3,
                                  child: Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: Column(
                                      // mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Container(
                                          child: Row(
                                            children: [
                                              (isFirst || selectedApp == 1)
                                                  ? Expanded(
                                                      child: ElevatedButton(
                                                      style: ButtonStyle(
                                                        backgroundColor:
                                                            MaterialStateProperty
                                                                .all<Color>(
                                                                    Colors
                                                                        .white),
                                                        shape: MaterialStateProperty
                                                            .all<
                                                                RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                          ),
                                                        ),
                                                      ),
                                                      child: Image.asset(
                                                        'assets/images/com.whatsapp.png',
                                                        width: 35,
                                                      ),
                                                      onPressed: () async {
                                                        setSelectedAppNumber(1);
                                                        await _sendMessage(
                                                            'com.whatsapp');
                                                        Navigator.pop(context);
                                                      },
                                                    ))
                                                  : Expanded(child: SizedBox()),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              (isFirst || selectedApp == 0)
                                                  ? Expanded(
                                                      child: ElevatedButton(
                                                      style: ButtonStyle(
                                                        backgroundColor:
                                                            MaterialStateProperty
                                                                .all<Color>(
                                                                    Colors
                                                                        .white),
                                                        shape: MaterialStateProperty
                                                            .all<
                                                                RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                          ),
                                                        ),
                                                      ),
                                                      child: Image.asset(
                                                        'assets/images/com.whatsapp.w4b.png',
                                                        width: 35,
                                                      ),
                                                      onPressed: () async {
                                                        setSelectedAppNumber(0);
                                                        await _sendMessage(
                                                            // 'com.whatsapp.w5b');
                                                            'com.whatsapp.w4b');
                                                        Navigator.pop(context);
                                                      },
                                                    ))
                                                  : Expanded(child: SizedBox()),




                                              SizedBox(
                                                width: 10,
                                              ),
                                              (isFirst || selectedApp == 10)
                                                  ? Expanded(
                                                  child: ElevatedButton(
                                                    style: ButtonStyle(
                                                      backgroundColor:
                                                      MaterialStateProperty
                                                          .all<Color>(
                                                          Colors
                                                              .white),
                                                      shape: MaterialStateProperty
                                                          .all<
                                                          RoundedRectangleBorder>(
                                                        RoundedRectangleBorder(
                                                          borderRadius:
                                                          BorderRadius
                                                              .circular(
                                                              50.0),
                                                        ),
                                                      ),
                                                    ),
                                                    child: Image.asset(
                                                      'assets/images/com.whatsapp.w4b.png',
                                                      color: Colors.yellow,
                                                      width: 35,
                                                    ),
                                                    onPressed: () async {
                                                      setSelectedAppNumber(10);
                                                      await _sendMessage(
                                                        'com.whatsapp.w5b');
                                                          // 'com.whatsapp.w4b');
                                                      Navigator.pop(context);
                                                    },
                                                  ))
                                                  : Expanded(child: SizedBox()),





                                              SizedBox(
                                                width: 10,
                                              ),
                                              (isFirst || selectedApp == 2)
                                                  ? Expanded(
                                                      child: ElevatedButton(
                                                      style: ButtonStyle(
                                                        backgroundColor:
                                                            MaterialStateProperty
                                                                .all<Color>(
                                                                    Colors
                                                                        .white),
                                                        shape: MaterialStateProperty
                                                            .all<
                                                                RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                          ),
                                                        ),
                                                      ),
                                                      child: Image.asset(
                                                        'assets/images/com.WhatsApp4Plus.png',
                                                        width: 30,
                                                      ),
                                                      onPressed: () async {

                                                        setSelectedAppNumber(2);
                                                        await _sendMessage(
                                                            'com.WhatsApp4Plus');
                                                        Navigator.pop(context);
                                                      },
                                                    ))
                                                  : Expanded(child: SizedBox()),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              (isFirst || selectedApp == 3)
                                                  ? Expanded(
                                                      child: ElevatedButton(
                                                      style: ButtonStyle(
                                                        backgroundColor:
                                                            MaterialStateProperty
                                                                .all<Color>(
                                                                    Colors
                                                                        .white),
                                                        shape: MaterialStateProperty
                                                            .all<
                                                                RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                          ),
                                                        ),
                                                      ),
                                                      child: Image.asset(
                                                        'assets/images/com.gbwhatsapp.png',
                                                        width: 25,
                                                      ),
                                                      onPressed: () async {

                                                        setSelectedAppNumber(3);
                                                        await _sendMessage(
                                                            'com.gbwhatsapp');
                                                        Navigator.pop(context);
                                                      },
                                                    ))
                                                  : Expanded(child: SizedBox()),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          child: Row(
                                            children: [
                                              (isFirst || selectedApp == 4)
                                                  ? Expanded(
                                                      child: ElevatedButton(
                                                        style: ButtonStyle(
                                                          backgroundColor:
                                                              MaterialStateProperty
                                                                  .all<Color>(
                                                                      Colors
                                                                          .white),
                                                          shape: MaterialStateProperty
                                                              .all<
                                                                  RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          50.0),
                                                            ),
                                                          ),
                                                        ),
                                                        child: Image.asset(
                                                          'assets/images/kb.png',
                                                          width: 30,
                                                        ),
                                                        onPressed: () async {
                                                          setSelectedAppNumber(4);
                                                          await _sendMessage(
                                                              'com.kbwhatsapp');
                                                          Navigator.pop(
                                                              context);
                                                        },
                                                      ),
                                                    )
                                                  : Expanded(child: SizedBox()),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              (isFirst || selectedApp == 5)
                                                  ? Expanded(
                                                      child: ElevatedButton(
                                                      style: ButtonStyle(
                                                        backgroundColor:
                                                            MaterialStateProperty
                                                                .all<Color>(
                                                                    Colors
                                                                        .white),
                                                        shape: MaterialStateProperty
                                                            .all<
                                                                RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                          ),
                                                        ),
                                                      ),
                                                      child: Image.asset(
                                                        'assets/images/an.png',
                                                        width: 30,
                                                      ),
                                                      onPressed: () async {
                                                        setSelectedAppNumber(5);
                                                        await _sendMessage(
                                                            'com.anwhatsapp');
                                                        Navigator.pop(context);
                                                      },
                                                    ))
                                                  : Expanded(child: SizedBox()),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              (isFirst || selectedApp == 6)
                                                  ? Expanded(
                                                      child: ElevatedButton(
                                                      style: ButtonStyle(
                                                        backgroundColor:
                                                            MaterialStateProperty
                                                                .all<Color>(
                                                                    Colors
                                                                        .white),
                                                        shape: MaterialStateProperty
                                                            .all<
                                                                RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                          ),
                                                        ),
                                                      ),
                                                      child: Image.asset(
                                                        'assets/images/sn.png',
                                                        width: 30,
                                                      ),
                                                      onPressed: () async {
                                                        setSelectedAppNumber(6);
                                                        await _sendMessage(
                                                            'com.snwhatsapp');
                                                        Navigator.pop(context);
                                                      },
                                                    ))
                                                  : Expanded(child: SizedBox()),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              (isFirst || selectedApp == 7)
                                                  ? Expanded(
                                                      child: ElevatedButton(
                                                        style: ButtonStyle(
                                                          backgroundColor:
                                                              MaterialStateProperty
                                                                  .all<Color>(
                                                                      Colors
                                                                          .white),
                                                          shape: MaterialStateProperty
                                                              .all<
                                                                  RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          50.0),
                                                            ),
                                                          ),
                                                        ),
                                                        child: Image.asset(
                                                          'assets/images/ob4.png',
                                                          width: 30,
                                                        ),
                                                        onPressed: () async {
                                                          setSelectedAppNumber(7);
                                                          await _sendMessage(
                                                              'com.ob4whatsapp');
                                                          Navigator.pop(
                                                              context);
                                                        },
                                                      ),
                                                    )
                                                  : Expanded(child: SizedBox()),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        child: Padding(
                          padding: const EdgeInsets.all(14.0),
                          child: Text(
                            'New number',
                            style: TextStyle(fontSize: 15),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(
                              AppColors.appColor),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(50.0),
                            ),
                          ),
                        ),
                        onPressed: () async {
                          // setState(() {
                          //   isWelcome = true;
                          //   _start2 = 10;
                          // });
                          _messageController.clear();
                          getNewNumber();
                          // _messageController.text =
                          //     sendProvider.randomNumberData.message;


                          if (sendProvider.randomNumberData.campaignId
                                  .toString() ==
                              "-1") {
                            showDialog<void>(
                              context: context,
                              barrierDismissible: false,
                              // user must tap button!
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  title: const Text('Alert'),
                                  content: SingleChildScrollView(
                                    child: ListBody(
                                      children: const <Widget>[
                                        Text(
                                            'No more numbers for this campaign.'),
                                      ],
                                    ),
                                  ),
                                  actions: <Widget>[
                                    TextButton(
                                      child: const Text('Okay'),
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                    ),
                                  ],
                                );
                              },
                            );
                          }
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        child: Padding(
                          padding: const EdgeInsets.all(14.0),
                          child: Text(
                            'Reset to view all apps',
                            style: TextStyle(fontSize: 15),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(
                              AppColors.appColor),
                          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(50.0),
                            ),
                          ),
                        ),
                        onPressed: () async {
                          resetData();
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
    // : LoginScreen();
  }

  Future<bool> _requestPermission(Permission permission) async {
    if (await permission.isGranted) {
      return true;
    } else {
      var result = await permission.request();
      if (result == PermissionStatus.granted) {
        return true;
      }
    }
    return false;
  }
  //
  // void startTimer() {
  //   const oneSec = const Duration(seconds: 1);
  //   setState(() {
  //     _timer = new Timer.periodic(
  //       oneSec,
  //       (Timer timer) {
  //         if (_start == 0) {
  //           setState(() {
  //             timer.cancel();
  //           });
  //         } else {
  //           setState(() {
  //             _start--;
  //           });
  //         }
  //       },
  //     );
  //   });
  // }

  @override
  void dispose() {
    _timer.cancel();
    _timer2.cancel();
    _timer3.cancel();
    super.dispose();

  }

  // void waitingForSend() {
  //   const oneSec = const Duration(seconds: 1);
  //   setState(() {
  //     _timer = new Timer.periodic(
  //       oneSec,
  //           (Timer timer) {
  //         if (_start == 0) {
  //
  //         } else {
  //           setState(() {
  //             _start--;
  //           });
  //         }
  //       },
  //     );
  //   });
  // }

  void getNewNumberTimer() {
    const oneSec = const Duration(seconds: 1);
    setState(() {
      _timer2 = new Timer.periodic(
        oneSec,
            (Timer timer) {
          if (_start2 == 0) {
            setState(() {
              _start2 = 10;
              isWelcome = true;
              getNewNumber();
            });
          } else {
            setState(() {
              _start2--;
            });
          }
        },
      );
    });
  }

  void checkLoginDate() {
    const oneSec = const Duration(seconds: 1);
    setState(() {
      _timer3 = new Timer.periodic(
        oneSec,
            (Timer timer) {
          if (_start3 == 0) {
            setState(() {
              _start3 = 10;
            });
            // Provider.of<AuthProvider>(context,listen: false).checkLoginDate(context);
            Provider.of<AuthProvider>(context,listen: false).checkLogin(context);
          } else {
            setState(() {
              _start3--;
            });
          }
        },
      );
    });
  }

  Future getNewNumber()async{
    // return;
    resetData();
    setState(() {
      isWelcome = true;
    });
    final sendProvider = Provider.of<SendProvider>(context, listen: false);
    await sendProvider.getRandomNumber();
    _messageController.text = sendProvider.randomNumberData.message;
    getSendTypeAndData();

    // waitingForSend();
    printData();
  }

  getSendTypeAndData() {
    final sendProvider = Provider.of<SendProvider>(context, listen: false);
    if (sendProvider.randomNumberData.picture != '') {
      setState(() {
        fileURL = sendProvider.randomNumberData.picture;
        fileName = sendProvider.randomNumberData.picture.substring(sendProvider.randomNumberData.picture.lastIndexOf('/') + 1);
        _sendType = sendType.PHOTO;
      });
    } else if (sendProvider.randomNumberData.video != '') {
      setState(() {
        fileURL = sendProvider.randomNumberData.video;
        fileName = sendProvider.randomNumberData.video.substring(sendProvider.randomNumberData.video.lastIndexOf('/') + 1);
        _sendType = sendType.VIDEO;
      });
    } else if (sendProvider.randomNumberData.file != '') {
      setState(() {
        fileURL = sendProvider.randomNumberData.file;
        fileName = sendProvider.randomNumberData.file.substring(sendProvider.randomNumberData.file.lastIndexOf('/') + 1);
        _sendType = sendType.PDF;
      });
    } else {
      setState(() {
        fileURL = '';
        fileName = '';
        _sendType = sendType.TEXT;
      });
    }
  }

  _sendMessage(String package) async {

    final sendProvider = Provider.of<SendProvider>(context, listen: false);
    bool isInstalled = await DeviceApps.isAppInstalled(package);
    if (!isInstalled) {
      print('app not installed');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppColors.appColor,
          content: Text(
            'App Not Installed',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.red,
              fontStyle: FontStyle.italic,
            ),
          ),
        ),
      );
      return;
    }


    // setState((){
    //   _start = 10;
    // });
    // waitingForSend();


    int splitIdx = sendProvider.randomNumberData.message.indexOf('#message#');
    if(splitIdx ==-1){
      welcomeMessage =sendProvider.randomNumberData.message;
    }else{
      welcomeMessage = sendProvider.randomNumberData.message.substring(0, splitIdx);
      mainMessage = sendProvider.randomNumberData.message.substring(splitIdx + 9);
    }

    String? pid = UserPreferences.getUserTypePreference() == 'leader'
        ? UserPreferences.getUserIdPreference().toString()
        : UserPreferences.getPIDPreference().toString();

    String intNum = sendProvider.randomNumberData.randomNumberModelInt.toString();
    String userId = UserPreferences.getUserIdPreference() ?? "";
    String clientId = sendProvider.randomNumberData.clientId.toString();
    bool isLeader = UserPreferences.getUserTypePreference() == 'leader' ? true : false;
    String phoneNumber = sendProvider.randomNumberData.phones.trim();

    printData();

    sendProvider.launchWhatsApp(
      // 'hello ya zeft',
      isWelcome ? welcomeMessage : mainMessage,
      package,
      intNum,
      userId,
      pid,
      isLeader,
      clientId,
      isWelcome?null:fileURL,
      fileName,
      isWelcome?"+"+phoneNumber:phoneNumber,
      // "+201123488897",
      _sendType == sendType.TEXT?false:isWelcome,
    );

    if(_sendType == sendType.TEXT){
      getNewNumber();
        isWelcome = true;
    }else{
      if(!isWelcome){
        getNewNumber();
      }
      else{
        isWelcome = false;
      }
    }


    // for hide and show selected app

    if(_sendType == sendType.TEXT){
      setState(() {
        isFirst = true;
      });
    }else{
      isFirst = !isFirst;
    }

    // reset Timer

    // setState(() {
    //   _start = 7;
    // });


  }

  setSelectedAppNumber(int number){
    setState(() {
      selectedApp = number;
    });
  }

}
