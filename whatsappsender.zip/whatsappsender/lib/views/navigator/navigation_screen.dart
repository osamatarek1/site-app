import 'package:flutter/material.dart';
import 'package:whatsappsender/utill/colors.dart';
import 'package:whatsappsender/view_models/auth_provider.dart';
import 'package:whatsappsender/views/report/report_screen.dart';
import 'package:whatsappsender/views/send/send_screen.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
class NavigationScreen extends StatefulWidget {
  const NavigationScreen({Key? key}) : super(key: key);

  @override
  _NavigationScreenState createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  int _selectedIndex = 0;
  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static const List<Widget> _widgetOptions = <Widget>[
    SendScreen(),
    ReportScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  void initState() {
    _requestPermission(Permission.storage).then((value){
      print(value);
    });
    // Provider.of<AuthProvider>(context,listen: false).checkLoginDate(context);
    super.initState();
  }

  Future<bool> _requestPermission(Permission permission) async {
    print('ddd');
    if (await permission.isGranted) {
      return true;
    } else {
      var result = await permission.request();
      if (result == PermissionStatus.granted) {
        return true;
      }
    }
    await _requestPermission(Permission.storage);
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.arrow_forward_rounded),
            label: 'Sender',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business),
            label: 'Report',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: AppColors.appColor,
        selectedLabelStyle: TextStyle(
          fontWeight: FontWeight.bold,
        ),
        onTap: _onItemTapped,
      ),
    );
  }
}
