import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:whatsappsender/utill/snackbar_response.dart';
import 'package:whatsappsender/utill/colors.dart';
import 'package:whatsappsender/utill/user_prefrences.dart';
import 'package:whatsappsender/view_models/auth_provider.dart';
import 'package:whatsappsender/view_models/send_provider.dart';
import 'package:whatsappsender/views/navigator/navigation_screen.dart';
import 'package:whatsappsender/views/send/send_screen.dart';
import 'package:provider/provider.dart';
import 'package:whatsappsender/widgets/snackbar_widget.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

// enum userType { leader, underLeader }

class _LoginScreenState extends State<LoginScreen> {
  late TextEditingController _usernameController;
  late TextEditingController _passwordController;
  userType _radioGroup = userType.leader;
  var _checked;

  @override
  void initState() {
    super.initState();
    _checked = false;
    _usernameController = TextEditingController();
    _passwordController = TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                SizedBox(
                  height: 30,
                ),
                Image.asset(
                  'assets/images/loginlogo.png',
                  height: 300,
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  alignment: Alignment.center,
                  child: Text(
                    'Welcome Back',
                    style: GoogleFonts.alikeAngular(
                      textStyle: TextStyle(
                        fontSize: 30,
                        color: AppColors.appColor,
                        letterSpacing: 5,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Radio(
                          activeColor: AppColors.appColor,
                          onChanged: (val) {
                            setState(() {
                              _radioGroup = userType.leader;
                            });
                          },
                          value: userType.leader,
                          groupValue: _radioGroup,
                        ),
                        const Text('Leader'),
                      ],
                    ),
                    SizedBox(
                      width: 30,
                    ),
                    Row(
                      children: [
                        Radio(
                          activeColor: AppColors.appColor,
                          onChanged: (val) {
                            setState(() {
                              _radioGroup = userType.underLeader;
                            });
                          },
                          value: userType.underLeader,
                          groupValue: _radioGroup,
                        ),
                        const Text('Under Leader'),
                      ],
                    ),
                  ],
                ),
                SizedBox(
                  height: 30,
                ),
                TextField(
                  controller: _usernameController,
                  decoration: InputDecoration(
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(50.0)),
                        borderSide: BorderSide(color: AppColors.appColor)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(50.0),
                      borderSide: BorderSide(
                        width: 0,
                        style: BorderStyle.none,
                      ),
                    ),
                    fillColor: Colors.grey.withOpacity(0.2),
                    filled: true,
                    contentPadding: EdgeInsets.symmetric(horizontal: 20),
                    hintText: 'Username',
                    // labelStyle: ,
                  ),
                ),
                SizedBox(height: 30),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(50.0)),
                        borderSide: BorderSide(color: AppColors.appColor)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(50.0),
                      borderSide: BorderSide(
                        width: 0,
                        style: BorderStyle.none,
                      ),
                    ),
                    fillColor: Colors.grey.withOpacity(0.2),
                    filled: true,
                    contentPadding: EdgeInsets.symmetric(horizontal: 20),
                    hintText: 'Password',
                    // labelStyle: ,
                  ),
                ),
                SizedBox(height: 30),
                Row(
                  children: [
                    Checkbox(
                        activeColor: AppColors.appColor,
                        value: _checked,
                        onChanged: (val) {
                          setState(() {
                            _checked = val;
                          });
                        }),
                    Text('Remember me'),
                  ],
                ),
                SizedBox(height: 30),
                Container(
                  child: ElevatedButton(
                    child: Padding(
                      padding: const EdgeInsets.all(14.0),
                      child: authProvider.isLoading
                          ? SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              'Login',
                              style: TextStyle(fontSize: 18),
                            ),
                    ),
                    style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all<Color>(AppColors.appColor),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                      ),
                    ),
                    onPressed: () async {
                      if (_usernameController.text.trim() != '' &&
                          _passwordController.text.trim() != '') {
                        if (_radioGroup == userType.leader) {
                          // set user type leader
                          authProvider.setUserType(userType.leader);
                          print(authProvider.loginUserType);
                        } else {
                          // set user type under leader
                          authProvider.setUserType(userType.underLeader);
                          print(authProvider.loginUserType);
                        }
                        // login process
                        authProvider
                            .setUsername(_usernameController.text.trim());
                        authProvider
                            .setUserPassword(_passwordController.text.trim());

                        UserPreferences.setLoginPreference(_checked);
                        authProvider.setRememberMe(_checked);
                        SnackBarModel result = await authProvider.userLogin();

                        // display snackBar base on the login result
                        if (result.code == 200) {
                          ScaffoldMessenger.of(context).showSnackBar(displaySnackBar(result.message));
                          // await Provider.of<AuthProvider>(context,listen: false).saveDateTimeForLeader();
                          Navigator.of(context).pushReplacement(
                            MaterialPageRoute(
                              builder: (context) => NavigationScreen(),
                            ),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(displaySnackBar(result.message));
                        }
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                            displaySnackBar('Please fill login data.'));
                      }
                    },
                  ),
                ),
                SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
