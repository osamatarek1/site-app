import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:whatsappsender/utill/colors.dart';
import 'package:whatsappsender/utill/user_prefrences.dart';
import 'package:whatsappsender/view_models/auth_provider.dart';
import 'package:whatsappsender/views/login/login_screen.dart';
import 'package:whatsappsender/views/navigator/navigation_screen.dart';
import 'package:whatsappsender/views/send/send_screen.dart';
import 'package:provider/provider.dart';
import 'package:firebase_database/firebase_database.dart';
class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) async{
      bool isAvailable = await Provider.of<AuthProvider>(context,listen: false).checkCodeForUpdate();
      print('=================isAvailable==============');
      print(isAvailable);
      if(!isAvailable){
        _showMyDialog();
        return;
      }
      Timer(
        Duration(seconds: 3),
        ()async{


          await Provider.of<AuthProvider>(context, listen: false).isLoggedIn();

          Navigator.of(context).pushReplacement(
            MaterialPageRoute(
              builder: (context) =>
              Provider.of<AuthProvider>(context, listen: false).loggedIn
                  ? NavigationScreen()
                  : LoginScreen(),
            ),
          );
          }
      );
    });
  }

  Future<void> _showMyDialog() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Update'),
          content: SingleChildScrollView(
            child: ListBody(
              children: const <Widget>[
                Text('Please Update Your App'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Ok'),
              onPressed: () {
                SystemNavigator.pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Stack(
          children: [
            Image.asset(
              'assets/images/splash.png',
              fit: BoxFit.fill,
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
            ),
            Positioned(
              bottom: 50,
              child: Container(
                  width: MediaQuery.of(context).size.width,
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Wrap(
                        // mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Make life easy with ',
                            style: TextStyle(color: Colors.white, fontSize: 20),
                          ),
                          Text(
                            'WhatsApp Sender',
                            style: TextStyle(
                              color: AppColors.appColor,
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 40,
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width - 80,
                        child: Text(
                          'Now you can control all your campaign and control users reports.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 15,
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 40,
                      ),
                      // authProvider.loggedIn
                      //     ? SizedBox()
                      //     : Container(
                      //         child: ElevatedButton(
                      //           child: Text(
                      //             'Get Started',
                      //             style: TextStyle(fontSize: 18),
                      //           ),
                      //           style: ElevatedButton.styleFrom(
                      //             primary: Colors.teal,
                      //             onPrimary: Colors.white,
                      //             shadowColor: Colors.yellowAccent,
                      //             elevation: 5,
                      //           ),
                      //           onPressed: () {
                      //             Navigator.of(context).pushReplacement(
                      //               MaterialPageRoute(
                      //                 builder: (context) => LoginScreen(),
                      //               ),
                      //             );
                      //           },
                      //         ),
                      //       )
                    ],
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
