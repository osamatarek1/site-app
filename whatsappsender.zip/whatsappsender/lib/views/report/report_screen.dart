import 'package:flutter/material.dart';
import 'package:whatsappsender/utill/colors.dart';
import 'package:provider/provider.dart';
import 'package:whatsappsender/utill/user_prefrences.dart';
import 'package:whatsappsender/view_models/report_provider.dart';
import 'package:intl/intl.dart';
class ReportScreen extends StatefulWidget {
  const ReportScreen({Key? key}) : super(key: key);

  @override
  _ReportScreenState createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      Provider.of<ReportProvider>(context, listen: false)
          .userReport()
          .then((value) {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final reportProvider = Provider.of<ReportProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('User Report'),
        backgroundColor: AppColors.appColor,
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: reportProvider.isLoading?Container(
          alignment: Alignment.center,
          child: Image.asset(
            'assets/images/loginlogo.png',
            width: 150,
          ),
        ):RefreshIndicator(
          onRefresh: ()async{
            await Provider.of<ReportProvider>(context, listen: false)
                .userReport();
          },
          child: ListView(
            children: [
              Container(
                alignment: Alignment.center,
                child: Image.asset(
                  'assets/images/loginlogo.png',
                  width: 150,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Center(child: Text(DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now()),style: TextStyle(
                color: AppColors.appColor,
              ),)),
              SizedBox(
                height: 30,
              ),
              _rowBuilder(
                  "UserName:",
                  UserPreferences.getUserTypePreference() == "leader"
                      ? reportProvider.userData.userName??''
                      : reportProvider.userUnderLeaderData.userName??''),
              SizedBox(
                height: 20,
              ),
              _rowBuilder(
                  "fullName:",
                  UserPreferences.getUserTypePreference() == "leader"
                      ? reportProvider.userData.fullName
                      : reportProvider.userUnderLeaderData.fullName),
              SizedBox(
                height: 20,
              ),
              _rowBuilder(
                  "mobile:",
                  UserPreferences.getUserTypePreference() == "leader"
                      ? reportProvider.userData.mobile
                      : reportProvider.userUnderLeaderData.mobile),
              SizedBox(
                height: 20,
              ),
              _rowBuilder(
                  "messagesSent:",
                  UserPreferences.getUserTypePreference() == "leader"
                      ? reportProvider.userData.messagesSent.toString()
                      : reportProvider.userUnderLeaderData.messagesSent
                          .toString()),
              SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }
  Widget _rowBuilder(String label, String value) {
    return Row(
      children: [
        Container(
            width: 90,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: AppColors.appColor,
              ),
            )),
        SizedBox(
          width: 20,
        ),
        Expanded(
          child: Container(
            alignment: Alignment.center,
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(
                value,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: AppColors.appColor,
                ),
              ),
            ),
            decoration: BoxDecoration(
              color: Colors.grey.withOpacity(0.2),
              borderRadius: BorderRadius.circular(50),
            ),
          ),
        ),
      ],
    );
  }
}
