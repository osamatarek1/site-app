class AppConstants {
  //  APP  URLs
  static const String APP_BASE_URL =
      'http://kookysleman-001-site5.ctempurl.com';
  static const String LOGIN_PARENT_USER_API = '/api/Users';
  static const String LOGIN_UNDER_USER_API = '/api/UsersUnders';
  static const String RANDOM_MESSAGE_API = '/api/new/PhonesMs';
  static const String CHECK_CODE = '/api/AppNumbers';

  // sharedPreference keys
  static const String LOGIN_KEY = 'is_logged_in';
  static const String USER_USERNAME_KEY = 'userEmail';
  static const String USER_PASSWORD_KEY = 'userPassword';
  static const String USER_ID_KEY = 'userId';
  static const String USER_TYPE_KEY = 'userType';
  static const String PID_KEY = 'pid';
  static const String LOGIN_DATE = 'loginDate';

  // error code
  static const int USER_INVALID_RESPONSE = 100;
  static const int NO_INTERNET = 101;
  static const int UINVALID_FORMAT = 102;
  static const int UNKNOWN_ERROR = 103;

  // error message
  static const String USER_INVALID_RESPONSE_MESSAGE = 'Invalid response!';
  static const String NO_INTERNET_MESSAGE = 'No internet!';
  static const String UINVALID_FORMAT_MESSAGE = 'Invalid format!';
  static const String UNKNOWN_ERROR_MESSAGE = 'Unexpected error!';
}
