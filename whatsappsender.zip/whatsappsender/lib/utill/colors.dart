import 'package:flutter/material.dart';

class AppColors{
  static const Color appColor = Color(0xff236e62);
}