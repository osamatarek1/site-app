import 'package:shared_preferences/shared_preferences.dart';
import 'package:whatsappsender/utill/constants.dart';

class UserPreferences {
  static SharedPreferences? _preferences;

  static Future init() async {
    _preferences = await SharedPreferences.getInstance();
  }

  static Future clear() async {
    await _preferences!.clear();
  }

// set login preference status
  static setLoginPreference(bool isLoggedIn) {
    return _preferences!.setBool(AppConstants.LOGIN_KEY, isLoggedIn);
  }

// get login preference status
  static bool? getLoginPreference() {
    return _preferences!.getBool(AppConstants.LOGIN_KEY);
  }

  // set user preference data
  static setUserUsernamePreference(String username) async {
    await _preferences!.setString(AppConstants.USER_USERNAME_KEY, username);
  }

  static setUserPasswordPreference(String password) async {
    await _preferences!.setString(AppConstants.USER_PASSWORD_KEY, password);
  }

  static setUserTypePreference(String type) async {
    await init();
    await _preferences!.setString(AppConstants.USER_TYPE_KEY, type);
  }
  static setUserLoginDate(String date) async {
    await _preferences!.setString(AppConstants.LOGIN_DATE, date);
  }

  static setPIDPreference(int pid) async {
    await _preferences!.setInt(AppConstants.PID_KEY, pid);
  }

  //get user preference data
  static String? getUserUsernamePreference() {
    return _preferences!.getString(AppConstants.USER_USERNAME_KEY);
  }

  static String? getUserPasswordPreference() {
    return _preferences!.getString(AppConstants.USER_PASSWORD_KEY);
  }

  static String? getUserTypePreference() {
    return _preferences!.getString(AppConstants.USER_TYPE_KEY);
  }

  static String? getUserLoginDate() {
    return _preferences!.getString(AppConstants.LOGIN_DATE);
  }

  // user id preference data
  static setUserIdPreference(String id) async {
    await _preferences!.setString(AppConstants.USER_ID_KEY, id);
  }

  static String? getUserIdPreference() {
    return _preferences!.getString(AppConstants.USER_ID_KEY);
  }

  static int? getPIDPreference() {
    return _preferences!.getInt(AppConstants.PID_KEY);
  }
}
