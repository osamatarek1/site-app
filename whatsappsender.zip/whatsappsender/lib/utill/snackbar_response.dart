class SnackBarModel {
  int code;
  String message;

  SnackBarModel({required this.code, required this.message});
}
