import 'package:dio/dio.dart';
import 'package:whatsappsender/models/random_number_model.dart';
import 'package:whatsappsender/utill/api_response.dart';
import 'package:whatsappsender/utill/constants.dart';

class SendServices{
  static Future<Object> getRandomNumber(int oldId,String userId)async{
    try {
      Response response = await Dio().get(
          AppConstants.APP_BASE_URL + AppConstants.RANDOM_MESSAGE_API,
          queryParameters: {'oldid': oldId, 'userid': userId});

      print('=======================new number====================');
      print(response.data);
      print('=======================new number====================');

      if (response.statusCode == 200) {
        if(response.data.length == 0){
          return Failure(code: 404, errorResponse: 'No data.');
        }
        RandomNumberModel messageData = RandomNumberModel.fromJson(response.data[0]);
        return Success(code: 200, response: messageData);
      }
      return Failure(
        code: AppConstants.USER_INVALID_RESPONSE,
        errorResponse: AppConstants.USER_INVALID_RESPONSE_MESSAGE,
      );
    } on DioError {
      return Failure(
        code: AppConstants.NO_INTERNET,
        errorResponse: AppConstants.NO_INTERNET_MESSAGE,
      );
    } on FormatException {
      return Failure(
        code: AppConstants.UINVALID_FORMAT,
        errorResponse: AppConstants.UINVALID_FORMAT_MESSAGE,
      );
    } catch (e) {
      return Failure(
        code: AppConstants.UNKNOWN_ERROR,
        errorResponse: AppConstants.UNKNOWN_ERROR_MESSAGE,
      );
    }
  }
}