import 'package:dio/dio.dart';
import 'package:whatsappsender/models/random_number_model.dart';
import 'package:whatsappsender/utill/api_response.dart';
import 'package:whatsappsender/utill/constants.dart';

class ReportServices {
  static Future updateUserReport(int id, String userId, int pId, bool leader,
      bool exist, int clientid) async {
    print('=============update==============');
    print(id);
    print(userId);
    print(pId);
    print(leader);
    print(exist);
    print(clientid);
    print('=============update==============');
    Response response = await Dio().put(
        AppConstants.APP_BASE_URL + AppConstants.RANDOM_MESSAGE_API,
        queryParameters: {
          'id': id,
          'userid': leader==true? 0:userId,
          'pid': leader==true? userId: pId,
          'leader': leader,
          'exist': exist,
          'clientid': clientid,
        });
  }
}
