import 'package:dio/dio.dart';
import 'package:whatsappsender/models/user_model.dart';
import 'package:whatsappsender/models/user_under_leader_model.dart';
import 'package:whatsappsender/utill/api_response.dart';
import 'package:whatsappsender/utill/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';


class AuthServices {
  static Future<Object> userLogin(String username, String password) async {
    try {
      Response response = await Dio().get(
          AppConstants.APP_BASE_URL + AppConstants.LOGIN_PARENT_USER_API,
          queryParameters: {
            'username': username.toString(),
            'password': password.toString()
          });

      print(response);
      if (response.statusCode == 200) {
        if (response.data.length == 0) {
          return Failure(
              code: 404, errorResponse: 'Invalid email or password.');
        }
        UserModel userData = UserModel.fromJson(response.data[0]);
        saveDateTimeForLeader(userData.id.toString());
        return Success(code: 200, response: userData);
      }
      return Failure(
        code: AppConstants.USER_INVALID_RESPONSE,
        errorResponse: AppConstants.USER_INVALID_RESPONSE_MESSAGE,
      );
    } on FormatException {
      return Failure(
        code: AppConstants.UINVALID_FORMAT,
        errorResponse: AppConstants.UINVALID_FORMAT_MESSAGE,
      );
    } on DioError {
      return Failure(
        code: AppConstants.NO_INTERNET,
        errorResponse: AppConstants.NO_INTERNET_MESSAGE,
      );
    }catch (e) {
      print(e);
      return Failure(
        code: AppConstants.UNKNOWN_ERROR,
        errorResponse: AppConstants.UNKNOWN_ERROR_MESSAGE,
      );
    }
  }

  static Future<Object> userUnderParentLogin(
      String username, String password) async {
    try {
      Response response = await Dio().get(
          AppConstants.APP_BASE_URL + AppConstants.LOGIN_UNDER_USER_API,
          queryParameters: {
            'username': username.toString(),
            'password': password.toString()
          });
      print(response);
      if (response.statusCode == 200) {
        if (response.data.length == 0) {
          return Failure(
              code: 404, errorResponse: 'Invalid email or password.');
        }
        UserUnderLeaderModel userData = UserUnderLeaderModel.fromJson(response.data[0]);
        saveDateTimeForUnderLeader(userData.id.toString());
        return Success(code: 200, response: userData);
      }
      return Failure(
        code: AppConstants.USER_INVALID_RESPONSE,
        errorResponse: AppConstants.USER_INVALID_RESPONSE_MESSAGE,
      );
    }on FormatException {
      return Failure(
        code: AppConstants.UINVALID_FORMAT,
        errorResponse: AppConstants.UINVALID_FORMAT_MESSAGE,
      );
    } on DioError {
      return Failure(
        code: AppConstants.NO_INTERNET,
        errorResponse: AppConstants.NO_INTERNET_MESSAGE,
      );
    } catch (e) {
      print(e);
      return Failure(
        code: AppConstants.UNKNOWN_ERROR,
        errorResponse: AppConstants.UNKNOWN_ERROR_MESSAGE,
      );
    }
  }



  static Future saveDateTimeForLeader(String id)async{
    final response = await Dio().get('http://kookysleman-001-site5.ctempurl.com/api/Users/$id');
    print('============================login date for leader=======================');
    print(response.data);
    print('============================login date for leader=======================');
    UserModel userData = UserModel.fromJson(response.data);
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    _preferences.setString('loginData',userData.loginDate);
  }

  static Future saveDateTimeForUnderLeader(String id)async{
    final response = await Dio().get('http://kookysleman-001-site5.ctempurl.com/api/UsersUnders/$id');
    print('============================login date for under leader=======================');
    print(response.data);
    print('============================login date for under leader=======================');
    UserUnderLeaderModel userData = UserUnderLeaderModel.fromJson(response.data);
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    _preferences.setString('loginData',userData.loginDate);
  }

}
