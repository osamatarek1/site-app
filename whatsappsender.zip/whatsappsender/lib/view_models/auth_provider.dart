import 'package:flutter/material.dart';
import 'package:whatsappsender/models/code_for_update_model.dart';
import 'package:whatsappsender/models/user_under_leader_model.dart';
import 'package:whatsappsender/utill/snackbar_response.dart';
import 'package:whatsappsender/models/user_model.dart';
import 'package:whatsappsender/services/login_repo.dart';
import 'package:whatsappsender/utill/api_response.dart';
import 'package:whatsappsender/utill/user_prefrences.dart';
import 'package:dio/dio.dart';
import 'package:whatsappsender/views/login/login_screen.dart';

import '../utill/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum userType { leader, underLeader }

class AuthProvider extends ChangeNotifier {
  late bool _isLoading;
  late UserModel _userData;
  late UserUnderLeaderModel _userUnderLeaderData;
  late bool _loggedIn = false;
  late String _username;
  late String _userPassword;
  late userType _userType;
  late bool _rememberMe;

  AuthProvider() {
    _isLoading = false;
    isLoggedIn();
  }

  setUsername(String username) {
    _username = username;
    notifyListeners();
  }

  setUserPassword(String pass) {
    _userPassword = pass;
    notifyListeners();
  }

  String get username => _username;

  userType get loginUserType => _userType;

  String get userPassword => _userPassword;

  UserModel get userData => _userData;

  UserUnderLeaderModel get userUnderLeaderData => _userUnderLeaderData;

  bool get isLoading => _isLoading;

  bool get loggedIn => _loggedIn;

  bool get rememberMe => _rememberMe;

  Future isLoggedIn() async {
    await UserPreferences.init();
    if (UserPreferences.getLoginPreference() != null &&
        UserPreferences.getLoginPreference() == true) {
      _loggedIn = true;
      notifyListeners();
    } else {
      _loggedIn = false;
      notifyListeners();
    }
    print(loggedIn);
  }

  setLoading(bool isLoading) {
    _isLoading = isLoading;
    notifyListeners();
  }

  setRememberMe(bool rememberMe) {
    _rememberMe = rememberMe;
    notifyListeners();
  }

  setUserData(var user) async {
    _userData = user;
    await UserPreferences.init();
    await UserPreferences.setUserIdPreference(user.id.toString());
    await setUserPrefData();
    notifyListeners();
  }

  setUserUnderLeaderData(var user) async {
    _userUnderLeaderData = user;
    await UserPreferences.init();
    await UserPreferences.setUserIdPreference(user.id.toString());
    await setUserPrefData();
    notifyListeners();
  }

  setUserType(userType userType) {
    _userType = userType;
    notifyListeners();
  }

  setUserPrefData() async {
    await UserPreferences.init();
    await UserPreferences.setUserUsernamePreference(
        loginUserType == userType.leader
            ? _userData.userName
            : _userUnderLeaderData.userName);
    await UserPreferences.setUserPasswordPreference(userPassword);
    await UserPreferences.setUserIdPreference(loginUserType == userType.leader
        ? _userData.id.toString()
        : _userUnderLeaderData.id.toString());
    await UserPreferences.setUserTypePreference(
        loginUserType == userType.leader ? "leader" : "underLeader");

    await UserPreferences.setPIDPreference(_userUnderLeaderData.pid);


    // await UserPreferences.setUserLoginDate(
    //     loginUserType == userType.leader
    //         ? _userData.loginDate.toString()
    //         : _userUnderLeaderData.loginDate.toString());

    await setLoggedIn(true);
  }

  setLoggedIn(bool loggedIn) async {
    await UserPreferences.init();
    UserPreferences.setLoginPreference(_rememberMe ? true : false);
    await isLoggedIn();
    notifyListeners();
  }

  Future<SnackBarModel> userLogin() async {
    setLoading(true);
    var response;
    late UserModel newResponse;
    if (loginUserType == userType.leader) {
      print('1-1');
      response = await AuthServices.userLogin(username, _userPassword);

    } else {
      print('1-2');
      response =
          await AuthServices.userUnderParentLogin(username, _userPassword);
    }

    if (response is Success) {
      print('2');
      loginUserType == userType.leader
          ? setUserData(response.response)
          : setUserUnderLeaderData(response.response);


      print('3');
      setLoading(false);
      return SnackBarModel(
        code: 200,
        message: 'You logged in successfully',
      );
    }
    if (response is Failure) {
      print('4');
      setLoading(false);
      return SnackBarModel(
        code: 404,
        message: response.errorResponse,
      );
    }
    return SnackBarModel(code: 0, message: '');
  }

  Future<void> logOut() async {
    await UserPreferences.init();
    UserPreferences.clear();
    await isLoggedIn();
  }

  Future<bool> checkCodeForUpdate() async {
    Response response =
        await Dio().get(AppConstants.APP_BASE_URL + AppConstants.CHECK_CODE);
    print(response.data);

    if (response.statusCode == 200) {
      if (response.data.length != 0) {
        CodeForUpdateModel code = CodeForUpdateModel.fromJson(response.data[0]);
        if (code.appNumber1 != 2025) {
          return false;
        }
        print(code.appNumber1);
      }
    }
    return true;
  }


  Future saveDateTimeForLeader(String id)async{
    final response = await Dio().get('http://kookysleman-001-site5.ctempurl.com/api/Users/$id');
    print('============================login date for leader=======================');
    print(response.data);
    print('============================login date for leader=======================');
    UserModel userData = UserModel.fromJson(response.data);
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    _preferences.setString('loginData',userData.loginDate);
  }

  Future checkLogin(BuildContext context)async{
    await UserPreferences.init();
    String userType = UserPreferences.getUserTypePreference() ?? '';
    print('============================');
    print(userType);
    print('============================');

    if(userType == 'leader'){
      checkLoginDate(context);
    }else{
      checkLoginDateForUnderLeader(context);
    }

  }

  Future<void> checkLoginDate(BuildContext context) async {
    await UserPreferences.init();
    String userId = UserPreferences.getUserIdPreference() ?? '';
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    String userLoginDate = _preferences.getString('loginData') ?? '';
    final response = await Dio().get('http://kookysleman-001-site5.ctempurl.com/api/Users/$userId');
    print(response.data);
    UserModel userData = UserModel.fromJson(response.data);
    if(userLoginDate != userData.loginDate.toString()){
      logOut();
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>LoginScreen()));
    }
  }

  Future<void> checkLoginDateForUnderLeader(BuildContext context) async {
    await UserPreferences.init();
    String userId = UserPreferences.getUserIdPreference() ?? '';
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    String userLoginDate = _preferences.getString('loginData') ?? '';
    final response = await Dio().get('http://kookysleman-001-site5.ctempurl.com/api/UsersUnders/$userId');
    print(response.data);
    UserUnderLeaderModel userData = UserUnderLeaderModel.fromJson(response.data);
    if(userLoginDate != userData.loginDate.toString()){
      logOut();
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>LoginScreen()));
    }
  }
}
