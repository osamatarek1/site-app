import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:whatsappsender/models/random_number_model.dart';
import 'package:whatsappsender/services/report_service.dart';
import 'package:whatsappsender/services/send_repo.dart';
import 'package:whatsappsender/utill/api_response.dart';
import 'package:whatsappsender/utill/user_prefrences.dart';
import 'package:firebase_database/firebase_database.dart';

class SendProvider extends ChangeNotifier {
  late bool _isLoading;
  late RandomNumberModel _randomNumberData;

  RandomNumberModel get randomNumberData => _randomNumberData;
  int _oldId = 1260;

  SendProvider() {
    _isLoading = false;
    _randomNumberData = RandomNumberModel(
      randomNumberModelInt: 1260,
      phones: '',
      name: '',
      clientId: -1,
      userId: -1,
      userUnderId: -1,
      sentTime: DateTime.now(),
      sent: false,
      message: '',
      campaignId: -1,
      bind: false,
      exist: false,
      picture: "",
      file: "",
      video: "",
    );
  }

  bool get isLoading => _isLoading;

  int get messageOldId => _oldId;

  setMessageOldId(int oldId) {
    _oldId = oldId;
    notifyListeners();
  }

  setLoading(bool isLoading) {
    _isLoading = isLoading;
    notifyListeners();
  }

  setRandomNumberData(var data) async {
    _randomNumberData = data;
    setMessageOldId(_randomNumberData.randomNumberModelInt);
    notifyListeners();
  }

  Future getRandomNumber() async {
    setLoading(true);
    await UserPreferences.init();
    String? uType = UserPreferences.getUserTypePreference();
    String? userId;
    if (uType == 'underLeader') {
      userId = UserPreferences.getPIDPreference().toString();
    } else {
      userId = UserPreferences.getUserIdPreference();
    }

    print('===============================================');
    print(messageOldId);
    print('===============================================');
    var response = await SendServices.getRandomNumber(
        messageOldId, userId! );

    if (response is Success) {
      setRandomNumberData(response.response);
      setLoading(false);
    }
    if (response is Failure) {
      setRandomNumberData(RandomNumberModel(
        randomNumberModelInt: 1260,
        phones: '',
        name: '',
        clientId: -1,
        userId: -1,
        userUnderId: -1,
        sentTime: DateTime.now(),
        sent: false,
        message: '',
        campaignId: -1,
        bind: false,
        exist: false,
        picture: "",
        file: "",
        video: "",
      ));
      print('=======================');
      print('ay haga');
      print('=======================');
      print(response.errorResponse);
      setLoading(false);
    }

  }

  static const platform = MethodChannel('samples.flutter.dev/battery');

  Future launchWhatsApp(String msg, String package, String id, String userId, String pId, bool leader, String clientId,var fileUrl,String fileName,String number,bool isWelcomeMessage) async {

    String message = msg + " :'''";

    String uId= leader? '0': userId.toString();

    String parentId = leader? userId: pId;

    // pritn(phone);

    // await ReportServices.updateUserReport(
    //     randomNumberData.randomNumberModelInt,
    //     UserPreferences.getUserIdPreference() ?? "",
    //     UserPreferences.getPIDPreference() ?? 0,
    //     UserPreferences.getUserTypePreference() == 'leader' ? true : false,
    //     false,
    //     randomNumberData.clientId);

    // add file and video link


    print('============================= Data Before Send ==========================');
    print(package);
    print(id);
    print(uId);
    print(parentId);
    print(leader);
    print(clientId);
    print(number);
    print('============================= Data Before Send ==========================');

    await platform.invokeMethod('sendMessage', {
      'msg': message,
      // 'phone': '201006126863',
      'phone': number.trim(),
      'pkg': package,
      'id': id,
      'userId': uId,
      'pId': parentId,
      'leader': leader,
      'clientId': clientId,
      'filePath':fileUrl,
      'imgName':fileName,
      'isWelcomeMessage':isWelcomeMessage,
      // 'isWelcomeMessage':true,
    });

  }

}
