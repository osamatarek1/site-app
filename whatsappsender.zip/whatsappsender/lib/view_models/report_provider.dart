import 'package:flutter/material.dart';
import 'package:whatsappsender/models/user_model.dart';
import 'package:whatsappsender/models/user_under_leader_model.dart';
import 'package:whatsappsender/services/login_repo.dart';
import 'package:whatsappsender/utill/api_response.dart';
import 'package:whatsappsender/utill/user_prefrences.dart';

import 'auth_provider.dart';

class ReportProvider extends ChangeNotifier {
  late bool _isLoading;
  late UserModel _userData;
  late UserUnderLeaderModel _userUnderLeaderData;

  UserModel get userData => _userData;

  UserUnderLeaderModel get userUnderLeaderData => _userUnderLeaderData;

  bool get isLoading => _isLoading;

  ReportProvider() {
    _isLoading = false;
    // userReport();
  }

  setLoading(bool isLoading) {
    _isLoading = isLoading;
    notifyListeners();
  }

  setUserData(var user) async {
    _userData = user;
    notifyListeners();
  }

  setUserUnderLeaderData(var user) async {
    _userUnderLeaderData = user;
    notifyListeners();
  }

  Future userReport() async {
    await UserPreferences.init();
    print('===============');
    print(UserPreferences.getUserUsernamePreference());
    print(UserPreferences.getUserTypePreference());
    print(UserPreferences.getUserPasswordPreference());
    print('===============');

    setLoading(true);
    var response;
    if (UserPreferences.getUserTypePreference() == "leader") {
      print('1-1');
      response = await AuthServices.userLogin(
          UserPreferences.getUserUsernamePreference() ?? "",
          UserPreferences.getUserPasswordPreference() ?? "");
      setLoading(false);
    } else {
      print('1-2');
      response = await AuthServices.userUnderParentLogin(
          UserPreferences.getUserUsernamePreference() ?? "",
          UserPreferences.getUserPasswordPreference() ?? "");
      setLoading(false);
    }

    if (response is Success) {
      print('2');
      UserPreferences.getUserTypePreference() == "leader"
          ? setUserData(response.response)
          : setUserUnderLeaderData(response.response);

      print(_userData.messagesSent);
      print('3');
      setLoading(false);
    }
    if (response is Failure) {
      print(response.errorResponse);
      setLoading(false);
    }
  }
}
