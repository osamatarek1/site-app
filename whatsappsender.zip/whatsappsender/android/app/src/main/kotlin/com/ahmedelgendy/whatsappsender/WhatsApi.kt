package com.ahmedelgendy.whatsappsender4

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.PUT
import retrofit2.http.Url
import retrofit2.http.GET
import retrofit2.http.Query

interface WhatsApi {
    @PUT("api/new/PhonesMs")
    fun sendWhatsData(
            @Query("id") id: String?,
            @Query("userid") userid: String?,
            @Query("pid") pid: String?,
            @Query("leader") leader: Boolean?,
            @Query("exist") exist: Boolean?,
            @Query("clientid") clientid: String?
    ): Call<ResponseBody>

    @GET fun downloadFileWithDynamicUrlSync(@Url fileUrl: String?): Call<ResponseBody?>
}
