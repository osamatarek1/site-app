package com.ahmedelgendy.whatsappsender4

import android.util.Log
import io.flutter.embedding.android.FlutterActivity
import android.text.TextUtils


import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils.SimpleStringSplitter
import android.widget.Button
import java.net.URLEncoder

import android.content.Context
import android.content.ContextWrapper
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build.VERSION
import android.os.Build.VERSION_CODES
import android.os.StrictMode
import android.os.StrictMode.VmPolicy
import android.content.ComponentName




import androidx.annotation.NonNull
import com.ahmedelgendy.whatsappsender4.Whats5Business
import com.ahmedelgendy.whatsappsender4.ImageDownloader.downloadImage
//import com.sun.jndi.toolkit.url.Uri
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.util.*

private const val TAG = "MainActivity"

class MainActivity : FlutterActivity() {

   private val whatsAppPackageName = "com.whatsapp"
    private val WhatsApp4PlusPackageName = "com.WhatsApp4Plus"
    private val GbwhatsappPackageName = "com.gbwhatsapp"
    private val CHANNEL = "samples.flutter.dev/battery"

    private val kbWhatsPackageName = "com.kbwhatsapp"
    private val ANWhatsPackageName = "com.anwhatsapp"
    private val OBWhatsPackageName = "com.ob4whatsapp"
    private val NGWhatsPackageName = "com.snwhatsapp"
    private val whatsAppBusiness = "com.whatsapp.w4b"
    private val whatsApp5Business = "com.whatsapp.w5b"


    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
//            isAccessibilityOn()

            if (call.method.equals("sendMessage")) {
                val msg:String?  =call.argument("msg");
                val phone:String?  =call.argument("phone");
                val packageName:String?  =call.argument("pkg");
                val filePath:String?  =call.argument("filePath");
                val imgName:String?  =call.argument("imgName");
                isWelcomeMessage =call.argument("isWelcomeMessage");
                id =call.argument("id");
                userid =call.argument("userId");
                pid  =call.argument("pId");
                leader =call.argument("leader");
                clientid  =call.argument("clientId");

                Log.e("AAA","${filePath} -- ${imgName}")
                Log.e("AAA","${phone} -- ${isWelcomeMessage}")

                if (phone != null&&packageName!=null&&imgName!=null) {
                    sendMessage(message = msg,mobileNumber = phone,packageName = packageName,fileUrl = filePath,imageName = imgName)
                }
            } else {
                result.notImplemented()
            }
            // Note: this method is invoked on the main thread.
            // TODO
        }
    }

    fun sendMessage(
            mobileNumber: String,
            message: String?,
            packageName: String,
            fileUrl: String?,
            imageName: String
    ) {
        setMessageType(imageName)
        if(isWelcomeMessage == true || (isWelcomeMessage == false && fileUrl == null)){
            sendMessageWelcome(mobileNumber,message,packageName);
        }
        else if (fileUrl == null) {
            sendMessageWelcome(mobileNumber,message,packageName);
//            shareOnWhatsapp(mobileNumber, message, packageName)
        } else {
            downloadImage(
                    context = this,
                    imageName = imageName,
                    url = fileUrl
            ) {
                it?.let { uri ->
//                    Log.e("DDDD", it.toFile().length().toString() + " " + it.toFile().name)

                    shareOnWhatsapp(
                            packageName = packageName,
                            message = message,
                            fileUri = uri,
                            mobileNumber = mobileNumber

                    )

                }

            }
        }
    }

    private fun sendMessageWelcome(mobileNumber: String?, message: String?, packageName: String?) {
         if (!isAccessibilityOn(getPackageClass(packageName))) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            return
        }
        val sendIntent = Intent("android.intent.action.MAIN")
        sendIntent.action = Intent.ACTION_VIEW
        sendIntent.setPackage(packageName)
        val url = "https://api.whatsapp.com/send?phone=$mobileNumber&text=" + URLEncoder.encode(
                        message,
                        "UTF-8"
                )
        sendIntent.data = Uri.parse(url)
        if (sendIntent.resolveActivity(packageManager) != null) {
            startActivity(sendIntent)
        }
    }


    //------------------------------------------
//    fun sendMessage(
//            mobileNumber: String?,
//            message: String?,
//            packageName: String?,
//            fileUri: String?
//    ) {
//        if (!isAccessibilityOn(getPackageClass(packageName))) {
//            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
//            startActivity(intent)
//            return
//        }
//        val intent = Intent(Intent.ACTION_SEND)
//        intent.type = "text/plain"
//        intent.setPackage(packageName)
//        intent.putExtra(Intent.EXTRA_TEXT, if (!TextUtils.isEmpty(message)) message else "")
//        isImageSharing=false
//        if (fileUri != null) {
//            isImageSharing = true
//            intent.putExtra(
//                    Intent.EXTRA_STREAM, Uri.fromFile(
//                    File(fileUri)
//            )
//            )
//            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
//            intent.type = "image/*"
//        }
//        intent.putExtra("jid", "$mobileNumber@s.whatsapp.net") //phone number without "+" prefix
//
//        try {
//            startActivity(intent)
//        } catch (ex: Exception) {
//            ex.printStackTrace()
//            Log.e("error", ex.toString())
//        }
//    }

    //---------------------------------------



    private fun shareOnWhatsapp(
            mobileNumber: String,
            message: String?,
            packageName: String,
            fileUri: Uri? = null
    ) {
        if (!isAccessibilityOn(getPackageClass(packageName))) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            return
        }
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/plain"
        intent.setPackage(packageName)
        intent.putExtra(Intent.EXTRA_TEXT, if (!TextUtils.isEmpty(message)) message else "")
        isImageSharing = false
        if (fileUri != null) {
            isImageSharing = true
            intent.putExtra(
                    Intent.EXTRA_STREAM, fileUri
            )
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.type = getMessageType()

//            intent.type = "image/*"
//            intent.type = "application/pdf"

        }
        intent.putExtra("jid", "$mobileNumber@s.whatsapp.net") //phone number without "+" prefix
        try {
            startActivity(intent)
        } catch (ex: Exception) {
            ex.printStackTrace()
            Log.e("error", ex.toString())
        }
    }

    private fun getMessageType() = when (messageType) {
        MessageType.IMAGE -> "image/*"
        MessageType.FILE -> "application/*"
        MessageType.SOUND_MP3,MessageType.SOUND_MP4 -> "video/*"
        else -> "text/plain"

    }
    private fun setMessageType(fileName: String) {
        Log.e(TAG, "-----> ${fileName.substringAfterLast(".").lowercase(Locale.getDefault())}")
        messageType = when (fileName.substringAfterLast(".").lowercase(Locale.getDefault())) {
            "mp3" -> MessageType.SOUND_MP3
            "mp4" -> MessageType.SOUND_MP4
            "pdf", "docx" -> MessageType.FILE
            "png", "jpg", "jpeg" -> MessageType.IMAGE
            else -> MessageType.PLAIN_TEXT
        }
    }


    private fun getPackageClass(packageName: String?): Class<out AccessibilityService?> =
            when (packageName) {
                whatsAppPackageName -> WhatsappAccessibilityService::class.java
                GbwhatsappPackageName -> GbwhatsappService::class.java
                kbWhatsPackageName -> KBWhatsAppService::class.java
                ANWhatsPackageName -> ANwhatsappService::class.java
                OBWhatsPackageName -> OB4WhatsAppService::class.java
                NGWhatsPackageName -> NGWhatsAppService::class.java
                whatsAppBusiness -> WhatsApp4BService::class.java
                whatsApp5Business -> Whats5Business::class.java
                else -> WhatsAppPlusService::class.java
            }

    private fun isAccessibilityOn(clazz: Class<out AccessibilityService?>): Boolean {
        var accessibilityEnabled = 0
        val service: String = packageName.toString() + "/" + clazz.canonicalName
        try {
            accessibilityEnabled = Settings.Secure.getInt(
                    applicationContext.contentResolver,
                    Settings.Secure.ACCESSIBILITY_ENABLED
            )
        } catch (ignored: Settings.SettingNotFoundException) {
        }
        val colonSplitter = SimpleStringSplitter(':')
        if (accessibilityEnabled == 1) {
            val settingValue: String = Settings.Secure.getString(
                    applicationContext.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )
            if (settingValue != null) {
                colonSplitter.setString(settingValue)
                while (colonSplitter.hasNext()) {
                    val accessibilityService = colonSplitter.next()
                    if (accessibilityService.equals(service, ignoreCase = true)) {
                        return true
                    }
                }
            }
        }
        return false
    }
//    companion object {
//        var id: String? = null
//        var userid: String? = null
//        var pid: String? = null
//        var clientid: String? = null
//        var leader: Boolean? = null
//        var isImageSharing = false
//        var isWelcomeMessage: Boolean? = false
//    }
    override fun onDestroy() {
        super.onDestroy()
        isImageSharing = false
        id = null
        messageType = null
    }

    companion object {
        var id: String? = null
        var userid: String? = null
        var pid: String? = null
        var clientid: String? = null
        var leader: Boolean? = null
        var exist: Boolean? = null
        var isImageSharing = false
        var isWelcomeMessage: Boolean? = false
        var messageType: MessageType? = MessageType.PLAIN_TEXT

    }

    enum class MessageType {
        PLAIN_TEXT, IMAGE, FILE, SOUND_MP3,SOUND_MP4
    }


//    override fun onDestroy() {
//        super.onDestroy()
//        isImageSharing = false
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val builder = VmPolicy.Builder()
        StrictMode.setVmPolicy(builder.build())
        builder.detectFileUriExposure()

    }
}