package com.ahmedelgendy.whatsappsender4


import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent


private const val TAG = "WhatsService"

class WhatsappAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        sendMessage(
            this,
            sendId = "com.whatsapp:id/send",
            entryId = "com.whatsapp:id/entry"
        )


    }

    override fun onInterrupt() {
        Log.e(TAG, "interrapt")
    }


}