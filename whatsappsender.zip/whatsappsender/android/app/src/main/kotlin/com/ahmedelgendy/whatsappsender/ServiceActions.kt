package com.ahmedelgendy.whatsappsender4
//
//import android.accessibilityservice.AccessibilityService
//import android.util.Log
//import android.view.accessibility.AccessibilityNodeInfo
//import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
//import okhttp3.ResponseBody
//import retrofit2.Call
//import retrofit2.Callback
//import retrofit2.Response
//import retrofit2.Retrofit
//
//private const val TAG = "WhatsService"

//fun sendMessage(service: AccessibilityService, sendId: String, entryId: String) {
//    try {
//        if (service.rootInActiveWindow == null) {
//            return
//        }
//
//        val rootInActiveWindow = AccessibilityNodeInfoCompat.wrap(
//            service.rootInActiveWindow
//        )
//
//        // Whatsapp Message EditText id
//
//        val messageNodeList =
//            rootInActiveWindow.findAccessibilityNodeInfosByViewId(entryId)
//        if (messageNodeList == null || messageNodeList.isEmpty()) {
//
//            return
//        }
//
//        // check if the whatsapp message EditText field is filled with text and ending with your suffix (explanation above)
//        val messageField = messageNodeList[0]
//        if (messageField.text == null || messageField.text.isEmpty() || !messageField.text.toString()
//                .endsWith(":MESSAGE")
//        ) { // So your service doesn't process any message, but the ones ending your apps suffix
//
//            return
//        }
//
//        // Whatsapp send button id
//        val sendMessageNodeInfoList =
//            rootInActiveWindow.findAccessibilityNodeInfosByViewId(sendId)
//        if (sendMessageNodeInfoList == null || sendMessageNodeInfoList.isEmpty()) {
//            return
//        }
//        val sendMessageButton = sendMessageNodeInfoList[0]
//        if (!sendMessageButton.isVisibleToUser) {
//            return
//        }
//        // Now fire a click on the send button
//        sendMessageButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)
//
//        // Now go back to your app by clicking on the Android back button twice:
//        // First one to leave the conversation screen
//        // Second one to leave whatsapp
//        try {
//            Thread.sleep(500) // hack for certain devices in which the immediate back click is too fast to handle
//            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
//
//            Thread.sleep(500) // same hack as above
//        } catch (ignored: InterruptedException) {
//
//        }
//        sendWhatsApiData()
//        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
//
//    } catch (e: Exception) {
//        Log.e(TAG, "exception ${e}")
//    }
//}
//
//fun sendWhatsApiData() {
//    val retrofit = Retrofit.Builder()
//            .baseUrl("http://kookysleman-001-site5.ctempurl.com/")
//            .build()
//
//    val apiCall: Call<ResponseBody> =
//            retrofit.create(WhatsApi::class.java)
//                    .sendWhatsData(
//                            MainActivity.id,
//                            MainActivity.userid,
//                            MainActivity.pid,
//                            MainActivity.leader,
//                            true,
//                            MainActivity.clientid
//                    )
//    apiCall.enqueue(object : Callback<ResponseBody> {
//        override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
//            Log.e(
//                    TAG,
//                    "api send status ${response.isSuccessful} ${response.code()} ${response}"
//            )
//        }
//
//        override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
//            Log.e(TAG, "api send failure ${t.message}")
//
//        }
//    })
//
//}

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import com.ahmedelgendy.whatsappsender4.MainActivity.Companion.isImageSharing
import com.ahmedelgendy.whatsappsender4.MainActivity.Companion.isWelcomeMessage
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit

import com.ahmedelgendy.whatsappsender4.MainActivity.Companion.id
import com.ahmedelgendy.whatsappsender4.MainActivity.Companion.messageType

private const val TAG = "WhatsService"
//
//fun sendMessage(service: AccessibilityService, sendId: String, entryId: String) {
//    try {
//        Log.e(TAG, "service")
//        if (service.rootInActiveWindow == null) {
//            Log.e(TAG, "null rooinactivewindow")
//            return
//        }
//
//        val rootInActiveWindow = AccessibilityNodeInfoCompat.wrap(
//                service.rootInActiveWindow
//        )
//        // Whatsapp Message EditText id
//        if (!isImageSharing) {
//            val messageNodeList =
//                    rootInActiveWindow.findAccessibilityNodeInfosByViewId(entryId)
//            // check if the whatsapp message EditText field is filled with text and ending with your suffix (explanation above)
//            val messageField = messageNodeList[0]
//            if ((messageField.text == null || messageField.text.isEmpty() || !messageField.text.toString().endsWith(":Hi how are you"))
//            ) { // So your service doesn't process any message, but the ones ending your apps suffix
//                Log.e(TAG, "not valid edittext")
//                return
//            }
//        }
//        // Whatsapp send button id
//        val sendMessageNodeInfoList =
//                rootInActiveWindow.findAccessibilityNodeInfosByViewId(sendId)
//        if (sendMessageNodeInfoList == null || sendMessageNodeInfoList.isEmpty()) {
//            Log.e(TAG, "canot find button")
//
//            return
//        }
//        val sendMessageButton = sendMessageNodeInfoList[0]
//        if (!sendMessageButton.isVisibleToUser) {
//            Log.e(TAG, "button not visible ")
//
//            return
//        }
//        // Now fire a click on the send button
//        sendMessageButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)
//
//        // Now go back to your app by clicking on the Android back button twice:
//        // First one to leave the conversation screen
//        // Second one to leave whatsapp
//        try {
//            Thread.sleep(500) // hack for certain devices in which the immediate back click is too fast to handle
//            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
//            Thread.sleep(500) // same hack as above
//        } catch (ignored: InterruptedException) {
//
//        }
//        isImageSharing = false
//        sendWhatsApiData()
//        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
//    } catch (e: Exception) {
//        Log.e(TAG, "exception ${e}")
//    }
//}

fun sendMessage(service: AccessibilityService, sendId: String, entryId: String) {
    try {
        if (service.rootInActiveWindow == null) {
            Log.e(TAG, "null rooinactivewindow")
            return
        }
        val rootInActiveWindow = AccessibilityNodeInfoCompat.wrap(
            service.rootInActiveWindow
        )
        // Whatsapp Message EditText id
        if (!isImageSharing && (messageType !in arrayListOf(MainActivity.MessageType.FILE,MainActivity.MessageType.SOUND_MP3))) {
            val messageNodeList =
                rootInActiveWindow.findAccessibilityNodeInfosByViewId(entryId)
            // check if the whatsapp message EditText field is filled with text and ending with your suffix (explanation above)
            val messageField = messageNodeList[0]
            if ((messageField.text == null || messageField.text.isEmpty() || !messageField.text.toString()
                    .endsWith(" :'''"))
            ) { // So your service doesn't process any message, but the ones ending your apps suffix
                Log.e(TAG, "not valid edittext")
                return
            }
        }
        if (messageType != null && (messageType !in arrayListOf(MainActivity.MessageType.FILE,MainActivity.MessageType.SOUND_MP3))) {
            // Whatsapp send button id
            val sendMessageNodeInfoList =
                rootInActiveWindow.findAccessibilityNodeInfosByViewId(sendId)
            if (sendMessageNodeInfoList == null || sendMessageNodeInfoList.isEmpty()) {
                Log.e(TAG, "canot find button 1")

                return
            }
            val sendMessageButton = sendMessageNodeInfoList[0]
            if (!sendMessageButton.isVisibleToUser) {
                Log.e(TAG, "button not visible ")
                return
            }
            Thread.sleep(500)
            // Now fire a click on the send button
            sendMessageButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            sendWhatsApiData()
        } else
            Thread.sleep(2000)
        // Now go back to your app by clicking on the Android back button twice:
        // First one to leave the conversation screen
        // Second one to leave whatsapp
        try {
            Thread.sleep(500) // hack for certain devices in which the immediate back click is too fast to handle
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            Thread.sleep(500) // same hack as above
        } catch (ignored: InterruptedException) {

        }
        isImageSharing = false
        messageType=null
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    } catch (e: Exception) {
        Log.e(TAG, "exception ${e}")
    }
}


fun sendWhatsApiData() {
    if (isWelcomeMessage == true)
        return;
    val retrofit = Retrofit.Builder()
        .baseUrl("http://kookysleman-001-site5.ctempurl.com/")
        .build()
    if (id == null) return
    val apiCall: Call<ResponseBody> =
        retrofit.create(WhatsApi::class.java).sendWhatsData(
            MainActivity.id,
            MainActivity.userid,
            MainActivity.pid,
            MainActivity.leader,
            true,
            MainActivity.clientid
        )
    apiCall.enqueue(object : Callback<ResponseBody> {
        override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
            Log.e(
                TAG,
                "api send status ${response.isSuccessful} ${response.code()} ${response}"
            )
        }

        override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
            Log.e(TAG, "api send failure ${t.message}")
        }
    })
    id = null

}


//
//fun sendWhatsApiData() {
//    if(isWelcomeMessage == false)
//        return;
//    val retrofit = Retrofit.Builder()
//            .baseUrl("http://kookysleman-001-site5.ctempurl.com/")
//            .build()
//
//    val apiCall: Call<ResponseBody> =
//            retrofit.create(WhatsApi::class.java).sendWhatsData(
//                            MainActivity.id,
//                            MainActivity.userid,
//                            MainActivity.pid,
//                            MainActivity.leader,
//                            true,
//                            MainActivity.clientid
//                    )
//    apiCall.enqueue(object : Callback<ResponseBody> {
//        override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
//            Log.e(
//                    TAG,
//                    "api send status ${response.isSuccessful} ${response.code()} ${response}"
//            )
//        }
//
//        override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
//            Log.e(TAG, "api send failure ${t.message}")
//
//        }
//    })
//
//
//}


