package com.ahmedelgendy.whatsappsender4

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class GbwhatsappService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        sendMessage(
            this,
            sendId = "com.gbwhatsapp:id/send",
            entryId = "com.gbwhatsapp:id/entry"
        )
    }

    override fun onInterrupt() {

    }

}
