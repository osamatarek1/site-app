package com.ahmedelgendy.whatsappsender4

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent


class NGWhatsAppService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        sendMessage(
                this,
                sendId = "com.snwhatsapp:id/send",
                entryId = "com.snwhatsapp:id/entry"
        )
    }

    override fun onInterrupt() {

    }

}