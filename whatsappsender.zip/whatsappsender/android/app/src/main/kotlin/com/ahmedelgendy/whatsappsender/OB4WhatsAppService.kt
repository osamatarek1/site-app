
package com.ahmedelgendy.whatsappsender4

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent


class OB4WhatsAppService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        sendMessage(
                this,
                sendId = "com.ob4whatsapp:id/send",
                entryId = "com.ob4whatsapp:id/entry"
        )
    }

    override fun onInterrupt() {

    }

}