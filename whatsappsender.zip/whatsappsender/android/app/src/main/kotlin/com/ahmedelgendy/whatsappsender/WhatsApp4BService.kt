package com.ahmedelgendy.whatsappsender4

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent


class WhatsApp4BService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        sendMessage(
            this,
            sendId = "com.whatsapp.w4b:id/send",
            entryId = "com.whatsapp.w4b:id/entry"
        )
    }

    override fun onInterrupt() {

    }

}
