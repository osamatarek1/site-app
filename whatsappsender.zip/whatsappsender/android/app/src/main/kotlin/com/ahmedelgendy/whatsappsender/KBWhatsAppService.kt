
package com.ahmedelgendy.whatsappsender4

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent


class KBWhatsAppService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        sendMessage(
                this,
                sendId = "com.kbwhatsapp:id/send",
                entryId = "com.kbwhatsapp:id/entry"
        )
    }

    override fun onInterrupt() {

    }

}