package com.ahmedelgendy.whatsappsender4
import android.net.Uri

import android.os.Environment
import android.util.Log
import android.widget.Toast
//import androidx.core.net.toUri

//import retrofit2.http.toUri
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import java.io.*
import android.os.Build
import android.content.Context



private const val TAG = "ImageDownloader"

object ImageDownloader {

    private fun getFileByName(fileName: String, context: Context): File {
        val path = if (Build.VERSION.SDK_INT >= 30) {
//            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)?.path + "/" + fileName
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)?.path + "/" + fileName
        } else {
            Environment.getExternalStorageDirectory()
                    .toString() + "/" + fileName
        }
        return File(path)
    }

    fun downloadImage(context: Context, url: String, imageName: String, getUri: (Uri?) -> Unit) {
//        val imageName = url.substringAfterLast("/")
        if (getFileByName(fileName = imageName, context)
                        .exists()
        ) {

            getUri(Uri.fromFile(getFileByName(fileName = imageName, context)))
//            getUri(getFileByName(fileName = imageName, context).toUri())
            return
        }
        val retrofit = Retrofit.Builder()
                .baseUrl("http://kookysleman-001-site5.ctempurl.com/")
                .build()

        val apiCall: Call<ResponseBody?> =
                retrofit.create(WhatsApi::class.java).downloadFileWithDynamicUrlSync(url)
        apiCall.enqueue(object : Callback<ResponseBody?> {
            override fun onResponse(
                    call: Call<ResponseBody?>,
                    response: Response<ResponseBody?>
            ) {
                if (response.isSuccessful) {
                    Log.e(TAG, "file downloaded successsfully")
                    getUri(
                            writeResponseBodyToDisk(
                                    response.body(), imageName, context
                            )
                    )
                } else {
                    Log.e(TAG, "download image failed")
                }
            }

            override fun onFailure(call: Call<ResponseBody?>, t: Throwable) {
                Log.e(TAG, "api send failure ${t.message}")
                Toast.makeText(context, "لم يتم تحميل الملف", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun writeResponseBodyToDisk(
            body: ResponseBody?,
            imageName: String,
            context: Context
    ): Uri? {
        return try {

            val file = getFileByName(fileName = imageName, context)
            var inputStream: InputStream? = null
            var outputStream: OutputStream? = null
            try {
                val fileReader = ByteArray(4096)
                val fileSize = body?.contentLength()
                var fileSizeDownloaded: Long = 0
                inputStream = body?.byteStream()
                outputStream = FileOutputStream(file)
                while (true) {
                    val read: Int = inputStream!!.read(fileReader)
                    if (read == -1) {
                        break
                    }
                    outputStream.write(fileReader, 0, read)
                    fileSizeDownloaded += read.toLong()
                    Log.d(TAG, "file download: $fileSizeDownloaded of $fileSize")
                }
                outputStream.flush()
                Uri.fromFile(file)
//                file.toUri()
            } catch (e: IOException) {
                Log.e(TAG, "error while saving image $e")
                Toast.makeText(context, "لم يتم حفظ الملف", Toast.LENGTH_LONG).show()

                null
            } finally {
                inputStream?.close()
                outputStream?.close()
            }
        } catch (e: IOException) {
            Log.e(TAG, "error while saving image $e")
            Toast.makeText(context, "لم يتم حفظ الملف", Toast.LENGTH_LONG).show()

            null
        }
    }
}