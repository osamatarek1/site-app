package com.ahmedelgendy.whatsappsender4


import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ANwhatsappService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        sendMessage(
                this,
                sendId = "com.anwhatsapp:id/send",
                entryId = "com.anwhatsapp:id/entry"
        )
    }

    override fun onInterrupt() {

    }

}