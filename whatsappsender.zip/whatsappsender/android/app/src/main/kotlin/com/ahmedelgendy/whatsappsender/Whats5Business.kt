package com.ahmedelgendy.whatsappsender4

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.ahmedelgendy.whatsappsender4.sendMessage

class Whats5Business : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        sendMessage(
            this,
            sendId = "com.whatsapp.w5b:id/send",
            entryId = "com.whatsapp.w5b:id/entry"
        )
    }

    override fun onInterrupt() {

    }

}
